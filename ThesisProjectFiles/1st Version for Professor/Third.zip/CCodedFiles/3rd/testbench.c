#include <stdio.h>


void aes_main();


int main ()
{
  int out[32];
  int key[32];
  int statemt[32];
  statemt[0] = 50;
  statemt[1] = 67;
  statemt[2] = 246;
  statemt[3] = 168;
  statemt[4] = 136;
  statemt[5] = 90;
  statemt[6] = 48;
  statemt[7] = 141;
  statemt[8] = 49;
  statemt[9] = 49;
  statemt[10] = 152;
  statemt[11] = 162;
  statemt[12] = 224;
  statemt[13] = 55;
  statemt[14] = 7;
  statemt[15] = 52;

  key[0] = 43;
  key[1] = 126;
  key[2] = 21;
  key[3] = 22;
  key[4] = 40;
  key[5] = 174;
  key[6] = 210;
  key[7] = 166;
  key[8] = 171;
  key[9] = 247;
  key[10] = 21;
  key[11] = 136;
  key[12] = 9;
  key[13] = 207;
  key[14] = 79;
  key[15] = 60;
  aes_main(statemt,key,out);

   printf ("encrypted message EDW!! \t");
   for (int i = 0; i < 4 * 4; ++i)
  {
       if (out[i] < 16)
       printf ("0");
       printf ("%x", out[i]);
     }
   printf ("\n");
return 0;
    }
