#include<stdio.h>




// in - it is the array that holds the plain text to be encrypted.
// out - it is the array that holds the key for encryption.
// state - the array that holds the intermediate results during encryption.


void Cipher(int Nr,int Nk,unsigned char out[16]);

int main()
{
	int i,Nr,Nk;
	unsigned char out[16];
	Nr=128;
	Nk = Nr / 32;
	Nr = Nk + 6;

	Cipher(Nr,Nk,out);

	// Output the encrypted text.
	printf("\nText after encryption:\n");
		for(i=0;i<Nk*4;i++)
		{
			printf("%02x ",out[i]);
		}
		printf("\n\n");
	return 0;

}
